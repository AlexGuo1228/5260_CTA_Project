"""Strategy and backtest configuration.

All tunable parameters live here so that a run is fully described by one
`BacktestConfig` object (it is also written next to the results).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional


@dataclass
class BacktestConfig:
    # ---- Data -----------------------------------------------------------
    returns_path: str = "data/MonthlyReturns.csv"
    asset_map_path: str = "data/AssetMapCsv.csv"
    # Zip of daily futures prices (one CSV per instrument ID).
    daily_zip_path: str = "data/FuturesUnderlyingData.zip"
    # Fill gaps in the monthly panel from the daily closes. The panel leaves a
    # month blank when the exchange was shut on the calendar month-end date
    # (UK Christmas / Easter, Lunar New Year), which also blanks the next
    # month. The daily file has trades in those months, so the return can be
    # rebuilt from the last close of each month.
    # MonthlyReturns.csv in data/ already has these gaps filled (the original
    # upload is kept as MonthlyReturns_original.csv), so this is off.
    fill_gaps_from_daily: bool = False

    # Instruments dropped as near-duplicates of another instrument that stays
    # in the universe (YM ~ ZD Dow Jones, XX ~ XU Stoxx 50).
    drop_instruments: List[str] = field(default_factory=lambda: ["YM", "XX"])

    # Asset class overrides applied on top of the asset map.
    # EC (Eurodollar) is a USD short-rate future, not a currency.
    asset_class_overrides: Dict[str, str] = field(default_factory=lambda: {"EC": "FI"})

    # ---- Sample -------------------------------------------------------
    # First and last month whose returns are evaluated ("YYYY-MM"). History
    # before start_date is still used to warm up signals and volatility.
    start_date: Optional[str] = "1995-01"
    end_date: Optional[str] = None

    # ---- Signal ---------------------------------------------------------
    # Time-series momentum lookback in months (cumulative return t-L+1..t).
    momentum_lookback: int = 12

    # ---- Volatility estimation -----------------------------------------
    # Trailing window of monthly returns used for the EMA volatility.
    vol_window: int = 12
    # EMA span (alpha = 2 / (span + 1)); the most recent month gets the
    # largest weight.
    vol_ema_span: float = 12.0
    # If True, squared deviations from the window EMA mean are used; the
    # default (False) uses raw squared returns (zero-mean assumption).
    vol_demean: bool = False
    # Optional floor on the annualised vol estimate used for sizing (e.g.
    # 0.02). Limits the notional given to near-zero-vol short-rate futures.
    vol_floor: Optional[float] = None

    # ---- Eligibility ----------------------------------------------------
    # Minimum number of valid monthly returns inside the trailing window.
    min_obs: int = 10
    # Minimum number of eligible instruments for the portfolio to trade;
    # earlier months are flat and excluded from statistics.
    min_assets: int = 10

    # ---- Portfolio construction ----------------------------------------
    # "equal_weight", "inverse_vol" or "erc".
    weighting: str = "inverse_vol"
    # Gross exposure (sum of |w|) after normalisation.
    gross_exposure: float = 1.0
    # Optional ex-ante annualised portfolio volatility target (e.g. 0.10).
    # When set, gross_exposure normalisation is followed by a scalar
    # rescale so that the ex-ante portfolio vol equals the target.
    vol_target: Optional[float] = None
    # Upper bound on gross exposure after vol targeting.
    max_gross_leverage: float = 10.0

    # ERC settings (used only when weighting == "erc").
    # Covariance window can be longer than the vol window because a 12-month
    # sample cannot identify a ~50 x 50 covariance matrix.
    cov_window: int = 12
    cov_ema_span: float = 12.0
    # Shrinkage intensity towards the diagonal: S = (1-d) * S_hat + d * diag(S_hat).
    cov_shrinkage: float = 0.5

    # ---- Costs ----------------------------------------------------------
    # One-way transaction cost in basis points of traded notional.
    cost_bps: float = 0.0

    # ---- Output ---------------------------------------------------------
    name: str = "cta"

    def to_dict(self) -> dict:
        return asdict(self)
