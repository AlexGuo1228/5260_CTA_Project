"""Cross-asset CTA (time-series momentum) backtest framework."""
from .config import BacktestConfig
from .data import load_market_data, coverage_table
from .engine import run_backtest, BacktestResult
from .weights import CTAStrategy
from . import metrics

__all__ = ["BacktestConfig", "load_market_data", "coverage_table", "run_backtest",
           "BacktestResult", "CTAStrategy", "metrics"]
