"""Trend signals.

Every function here receives a history that ends at the signal date t and
returns a value per instrument that may only depend on that history.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def tsmom_sign(history: pd.DataFrame, lookback: int) -> pd.Series:
    """Time-series momentum: sign of the cumulative return over the last
    `lookback` months (t-lookback+1 .. t inclusive).

    Missing months inside the window are treated as a zero return.
    Returns +1 (long), -1 (short) or 0 (flat when the cumulative return is
    exactly zero or there is no data).
    """
    window = history.iloc[-lookback:]
    cum = (1.0 + window.fillna(0.0)).prod() - 1.0
    sig = np.sign(cum)
    sig[window.notna().sum() == 0] = 0.0
    return sig.astype(float)
