"""Portfolio construction.

`CTAStrategy.compute_weights(history)` is the single entry point used by the
backtest engine. `history` holds returns up to and including the signal
month t and nothing later; the engine guarantees that, so this module never
needs to know which month it is.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from .config import BacktestConfig
from .risk import ema_covariance, ema_volatility, ema_weights
from .signals import tsmom_sign


def eligible_mask(history: pd.DataFrame, window: int, min_obs: int) -> pd.Series:
    """Instruments that can be traded at the end of `history`.

    Requirements:
      * a return is observed in the signal month itself (still trading);
      * the instrument's first observation is at least `window` months old,
        so the full trailing window is spanned;
      * at least `min_obs` valid returns inside the trailing window.
    """
    last = history.iloc[-1].notna()
    first_pos = history.notna().values.argmax(axis=0)
    has_any = history.notna().any().values
    age_ok = pd.Series((len(history) - first_pos >= window) & has_any, index=history.columns)
    count_ok = history.iloc[-window:].notna().sum() >= min_obs
    return last & age_ok & count_ok


def erc_weights(cov: np.ndarray, tol: float = 1e-10, max_iter: int = 2000) -> np.ndarray:
    """Equal risk contribution weights (long-only on the signed covariance)
    via cyclical coordinate descent (Griveau-Billion, Richard, Roncalli 2013).
    Returns weights that sum to one.
    """
    n = cov.shape[0]
    b = np.full(n, 1.0 / n)
    w = 1.0 / np.sqrt(np.diag(cov))
    w = w / w.sum()
    for _ in range(max_iter):
        w_old = w.copy()
        for i in range(n):
            s_ii = cov[i, i]
            c_i = cov[i] @ w - s_ii * w[i]
            w[i] = (-c_i + np.sqrt(c_i * c_i + 4.0 * s_ii * b[i])) / (2.0 * s_ii)
        if np.max(np.abs(w - w_old)) < tol * max(1.0, np.max(np.abs(w))):
            break
    return w / w.sum()


def risk_contributions(w: np.ndarray, cov: np.ndarray) -> np.ndarray:
    """Fraction of portfolio variance contributed by each position."""
    m = cov @ w
    tot = w @ m
    return w * m / tot


@dataclass
class CTAStrategy:
    cfg: BacktestConfig
    weighting: str = field(default="")
    # Instrument -> asset class; only needed for class_risk_parity.
    asset_class: Optional[pd.Series] = None

    def __post_init__(self) -> None:
        if not self.weighting:
            self.weighting = self.cfg.weighting
        if self.weighting not in {"equal_weight", "inverse_vol", "erc", "class_risk_parity"}:
            raise ValueError(f"Unknown weighting: {self.weighting}")

    def compute_weights(self, history: pd.DataFrame) -> pd.Series:
        cfg = self.cfg
        cols = history.columns
        out = pd.Series(0.0, index=cols)

        lookback = max(cfg.momentum_lookback, cfg.vol_window)
        elig = eligible_mask(history, lookback, cfg.min_obs)
        sig = tsmom_sign(history, cfg.momentum_lookback)
        vol = ema_volatility(history, cfg.vol_window, cfg.vol_ema_span, cfg.vol_demean)
        elig &= vol.notna() & (vol > 0) & (sig != 0)
        if cfg.vol_floor is not None:
            vol = vol.clip(lower=cfg.vol_floor)
        names = cols[elig.values]
        if len(names) < cfg.min_assets:
            return out

        if self.weighting == "equal_weight":
            raw = pd.Series(1.0, index=names)
        elif self.weighting == "inverse_vol":
            raw = 1.0 / vol[names]
        elif self.weighting == "class_risk_parity":
            raw = self._class_risk_parity(history[names], sig[names], vol[names])
        else:  # erc
            cov = ema_covariance(history[names], cfg.cov_window, cfg.cov_ema_span, cfg.cov_shrinkage)
            s = sig[names].values
            # Covariance of the signed positions: a short position flips the
            # sign of its covariance with every long position.
            signed_cov = cov.values * np.outer(s, s)
            raw = pd.Series(erc_weights(signed_cov), index=names)

        w = sig[names] * raw
        w = w / w.abs().sum() * cfg.gross_exposure

        if cfg.vol_target is not None:
            w = self._apply_vol_target(history[names], w)

        out.loc[names] = w.values
        return out

    def _sleeve_vol(self, hist: pd.DataFrame, w: pd.Series) -> float:
        """Ex-ante annualised vol of a weight vector: EMA volatility of the
        hypothetical returns these weights would have earned over the
        trailing window (captures correlations without a matrix inverse)."""
        cfg = self.cfg
        x = hist.iloc[-cfg.vol_window:].fillna(0.0)
        pr = x.values @ w.values
        ew = ema_weights(len(pr), cfg.vol_ema_span)
        return float(np.sqrt((ew * pr ** 2).sum() * 12.0))

    def _class_risk_parity(self, hist: pd.DataFrame, sig: pd.Series, vol: pd.Series) -> pd.Series:
        """Two-level risk parity: inverse-vol inside each asset class, then
        each class sleeve scaled by the inverse of its ex-ante sleeve vol so
        that every class carries the same standalone risk."""
        if self.asset_class is None:
            raise ValueError("class_risk_parity needs asset_class")
        cls = self.asset_class.reindex(hist.columns)
        raw = pd.Series(0.0, index=hist.columns)
        for _, members in cls.groupby(cls).groups.items():
            members = list(members)
            inner = 1.0 / vol[members]
            inner = inner / inner.sum()
            sv = self._sleeve_vol(hist[members], sig[members] * inner)
            if sv > 0:
                raw.loc[members] = inner / sv
        return raw

    def _apply_vol_target(self, hist: pd.DataFrame, w: pd.Series) -> pd.Series:
        """Scale weights so that the ex-ante portfolio vol hits the target.

        Ex-ante vol is the EMA volatility of the hypothetical return series
        that today's weights would have produced over the trailing window.
        This captures correlations without inverting a covariance matrix.
        """
        cfg = self.cfg
        port_vol = self._sleeve_vol(hist, w)
        if port_vol <= 0:
            return w
        scale = cfg.vol_target / port_vol
        scale = min(scale, cfg.max_gross_leverage / w.abs().sum())
        return w * scale
