"""Risk estimation: EMA volatility and EMA covariance on trailing windows."""
from __future__ import annotations

import numpy as np
import pandas as pd


def ema_weights(n: int, span: float) -> np.ndarray:
    """EMA weights for a window of n observations, oldest first.

    alpha = 2 / (span + 1); the newest observation gets weight proportional
    to 1, the one before (1 - alpha), and so on. Weights sum to 1.
    """
    alpha = 2.0 / (span + 1.0)
    w = (1.0 - alpha) ** np.arange(n - 1, -1, -1)
    return w / w.sum()


def ema_volatility(history: pd.DataFrame, window: int, span: float,
                   demean: bool = False, annualise: bool = True) -> pd.Series:
    """EMA volatility per instrument over the trailing `window` months.

    Missing observations are skipped and the EMA weights of the remaining
    observations are renormalised, so a gap does not bias the estimate
    towards zero.
    """
    x = history.iloc[-window:]
    w = pd.Series(ema_weights(len(x), span), index=x.index)
    valid = x.notna()
    wv = valid.mul(w, axis=0)
    wsum = wv.sum()
    xf = x.fillna(0.0)
    if demean:
        mu = xf.mul(wv).sum() / wsum
        sq = (xf - mu) ** 2
    else:
        sq = xf ** 2
    var = sq.mul(wv).sum() / wsum
    vol = np.sqrt(var)
    if annualise:
        vol = vol * np.sqrt(12.0)
    vol[wsum == 0] = np.nan
    return vol


def ema_covariance(history: pd.DataFrame, window: int, span: float,
                   shrinkage: float = 0.0, annualise: bool = True) -> pd.DataFrame:
    """Zero-mean EMA covariance over the trailing window, shrunk towards its
    own diagonal. Missing returns are treated as zero (instruments with too
    many gaps are removed by the eligibility filter before this is called).
    """
    x = history.iloc[-window:].fillna(0.0)
    w = ema_weights(len(x), span)
    xv = x.values
    s = (xv * w[:, None]).T @ xv
    if shrinkage > 0:
        s = (1.0 - shrinkage) * s + shrinkage * np.diag(np.diag(s))
    if annualise:
        s = s * 12.0
    return pd.DataFrame(s, index=x.columns, columns=x.columns)
