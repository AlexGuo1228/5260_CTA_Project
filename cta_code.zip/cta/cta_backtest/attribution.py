"""Performance attribution.

All attributions here are ex-post and use only the backtest output (held
weights and realised returns), so they add no look-ahead to the strategy.

Conventions
-----------
* A position's monthly contribution is w_{i,t} * r_{i,t+1} (weights held in
  month t+1 were decided at t); contributions sum exactly to the portfolio's
  gross-of-cost return.
* "Annualised" contribution = mean monthly contribution x 12, so class and
  instrument rows add up to the portfolio's annualised arithmetic return.
"""
from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd

from .engine import BacktestResult


def _group_sum(df: pd.DataFrame, groups: pd.Series) -> pd.DataFrame:
    """Sum columns of df by a column -> group mapping."""
    return df.T.groupby(groups.reindex(df.columns)).sum().T


def by_long_short(res: BacktestResult, asset_class: pd.Series) -> pd.DataFrame:
    """Annualised contribution of long and short positions per asset class."""
    w = res.held_weights
    c = res.contributions
    long_c = _group_sum(c.where(w > 0, 0.0), asset_class).mean() * 12
    short_c = _group_sum(c.where(w < 0, 0.0), asset_class).mean() * 12
    long_n = _group_sum((w > 0).astype(float), asset_class).mean()
    short_n = _group_sum((w < 0).astype(float), asset_class).mean()
    out = pd.DataFrame({
        "long_contrib": long_c,
        "short_contrib": short_c,
        "avg_n_long": long_n,
        "avg_n_short": short_n,
    })
    out.loc["TOTAL"] = [long_c.sum(), short_c.sum(), long_n.sum(), short_n.sum()]
    out.index.name = "asset_class"
    return out


def by_instrument(res: BacktestResult, asset_class: pd.Series, names: pd.Series) -> pd.DataFrame:
    """Per instrument: annualised contribution, average |weight|, months held
    and the share of held months with a positive contribution."""
    w = res.held_weights
    c = res.contributions
    held = w != 0
    out = pd.DataFrame({
        "name": names.reindex(w.columns),
        "asset_class": asset_class.reindex(w.columns),
        "ann_contrib": c.mean() * 12,
        "avg_abs_weight": w.abs().mean(),
        "months_held": held.sum(),
        "hit_rate": (c > 0).where(held).mean(),
        "pct_long": (w > 0).sum() / held.sum().replace(0, np.nan),
    })
    out = out[out["months_held"] > 0]
    return out.sort_values("ann_contrib", ascending=False)


def by_year_and_class(res: BacktestResult, asset_class: pd.Series) -> pd.DataFrame:
    """Calendar-year contribution (sum of monthly contributions) per class,
    plus the portfolio's compounded calendar-year return for reference."""
    cls = _group_sum(res.contributions, asset_class)
    yearly = cls.groupby(cls.index.year).sum()
    yearly["TOTAL_sum"] = yearly.sum(axis=1)
    yearly["portfolio_compounded"] = (1 + res.returns).groupby(res.returns.index.year).prod() - 1
    yearly.index.name = "year"
    return yearly


def active_attribution(port: BacktestResult, bench: BacktestResult,
                       asset_class: pd.Series) -> pd.DataFrame:
    """Brinson-style decomposition of (portfolio - benchmark) contribution by
    asset class, adapted to long/short futures books.

    For class c in month t, with G = gross exposure sum|w| in the class,
    S = G / total gross (class share of gross), R = contribution / G (return
    per unit of gross exposure):

      leverage  = (G_p,tot - G_b,tot) * S_b * R_b   more or less total gross
      mix       = G_p,tot * (S_p - S_b) * R_b       different class mix
      selection = G_p * (R_p - R_b)                 different sizing inside c

    The three effects add up exactly to contrib_p - contrib_b for each class
    and month. Both portfolios must hold the same instruments with the same
    signs (true here: they share the signal and eligibility rules).
    """
    idx = port.returns.index.intersection(bench.returns.index)
    wp, wb = port.held_weights.loc[idx], bench.held_weights.loc[idx]
    cp, cb = port.contributions.loc[idx], bench.contributions.loc[idx]

    gp, gb = _group_sum(wp.abs(), asset_class), _group_sum(wb.abs(), asset_class)
    kp, kb = _group_sum(cp, asset_class), _group_sum(cb, asset_class)
    gp_tot, gb_tot = gp.sum(axis=1), gb.sum(axis=1)
    sp = gp.div(gp_tot.replace(0, np.nan), axis=0).fillna(0.0)
    sb = gb.div(gb_tot.replace(0, np.nan), axis=0).fillna(0.0)
    rp = (kp / gp.replace(0, np.nan)).fillna(0.0)
    rb = (kb / gb.replace(0, np.nan)).fillna(0.0)

    leverage = sb.mul(gp_tot - gb_tot, axis=0) * rb
    mix = (sp - sb).mul(gp_tot, axis=0) * rb
    selection = gp * (rp - rb)

    diff = kp - kb
    resid = (leverage + mix + selection - diff).abs().to_numpy().max()
    assert resid < 1e-12, f"Attribution does not add up (max residual {resid})"

    out = pd.DataFrame({
        "portfolio_contrib": kp.mean() * 12,
        "benchmark_contrib": kb.mean() * 12,
        "difference": diff.mean() * 12,
        "leverage_effect": leverage.mean() * 12,
        "mix_effect": mix.mean() * 12,
        "selection_effect": selection.mean() * 12,
    })
    out.loc["TOTAL"] = out.sum()
    out.index.name = "asset_class"
    return out


def factor_series(returns: pd.DataFrame, asset_class: pd.Series) -> pd.DataFrame:
    """Passive long-only factors built from the same return panel:
    EQUITY = S&P 500 future (SP), BOND = 10y T-note future (TY),
    COMMODITY = equal-weight average of available commodity futures,
    FX = equal-weight average of available currency futures (long foreign
    currency vs USD).
    """
    cls = asset_class.reindex(returns.columns)
    return pd.DataFrame({
        "EQUITY": returns["SP"],
        "BOND": returns["TY"],
        "COMMODITY": returns.loc[:, cls == "COMM"].mean(axis=1),
        "FX": returns.loc[:, cls == "FX"].mean(axis=1),
    })


def factor_regression(port_returns: pd.Series, factors: pd.DataFrame) -> pd.Series:
    """OLS of monthly strategy returns on passive factors.

    Returns annualised alpha, betas, their t-stats and R^2. A trend strategy
    is expected to have small, unstable betas and most of its return in
    alpha (the payoff comes from switching sign, not from holding the asset).
    """
    df = pd.concat([port_returns.rename("y"), factors], axis=1, join="inner").dropna()
    y = df["y"].to_numpy()
    x = np.column_stack([np.ones(len(df)), df[factors.columns].to_numpy()])
    beta, *_ = np.linalg.lstsq(x, y, rcond=None)
    resid = y - x @ beta
    dof = len(y) - x.shape[1]
    sigma2 = resid @ resid / dof
    se = np.sqrt(np.diag(sigma2 * np.linalg.inv(x.T @ x)))
    tstat = beta / se
    r2 = 1 - resid @ resid / ((y - y.mean()) @ (y - y.mean()))
    out: Dict[str, float] = {"alpha_ann": beta[0] * 12, "alpha_t": tstat[0]}
    for k, name in enumerate(factors.columns, start=1):
        out[f"beta_{name}"] = beta[k]
        out[f"t_{name}"] = tstat[k]
    out["r2"] = r2
    out["months"] = len(y)
    return pd.Series(out)


def conditional_on_equity(port_returns: pd.Series, equity: pd.Series, q: float = 0.2) -> pd.Series:
    """Average strategy return in the worst and best `q` share of equity
    months ("crisis alpha" check)."""
    df = pd.concat([port_returns.rename("p"), equity.rename("e")], axis=1, join="inner").dropna()
    lo, hi = df["e"].quantile(q), df["e"].quantile(1 - q)
    return pd.Series({
        "avg_ret_worst_equity_months": df.loc[df["e"] <= lo, "p"].mean(),
        "avg_ret_best_equity_months": df.loc[df["e"] >= hi, "p"].mean(),
        "avg_ret_all_months": df["p"].mean(),
        "corr_with_equity": df["p"].corr(df["e"]),
    })
