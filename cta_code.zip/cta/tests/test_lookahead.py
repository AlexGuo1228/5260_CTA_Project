"""Tests that prove the backtest has no look-ahead bias, plus unit tests of
the risk building blocks.

Run from the project root:  python -m pytest -q
"""
from __future__ import annotations

import os
import sys

import numpy as np
import pandas as pd
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cta_backtest import BacktestConfig, CTAStrategy, load_market_data, run_backtest  # noqa: E402
from cta_backtest.risk import ema_covariance, ema_volatility, ema_weights  # noqa: E402
from cta_backtest.weights import erc_weights, risk_contributions  # noqa: E402

WEIGHTINGS = ["equal_weight", "inverse_vol", "erc", "class_risk_parity"]


@pytest.fixture(scope="module")
def market():
    cfg = BacktestConfig(
        returns_path=os.path.join(ROOT, "data/MonthlyReturns.csv"),
        asset_map_path=os.path.join(ROOT, "data/AssetMapCsv.csv"),
    )
    md = load_market_data(cfg)
    # A 1985-2000 slice keeps the tests fast while covering all asset classes.
    md.returns = md.returns.loc["1985":"2000"]
    return cfg, md


class RecordingStrategy:
    """Wraps a strategy and records the last date of every history it sees."""

    def __init__(self, inner):
        self.inner = inner
        self.seen = []

    def compute_weights(self, history):
        self.seen.append(history.index[-1])
        return self.inner.compute_weights(history)


@pytest.mark.parametrize("weighting", WEIGHTINGS)
@pytest.mark.parametrize("vol_target", [None, 0.10])
def test_weights_ignore_future_data(market, weighting, vol_target):
    """Scramble every return after month t. Weights decided at or before t
    must not change by a single bit, and the P&L of month t+1 must equal
    w_t . r_{t+1} computed by hand."""
    cfg, md = market
    cfg = BacktestConfig(**{**cfg.to_dict(), "vol_target": vol_target})
    strat = CTAStrategy(cfg, weighting, asset_class=md.asset_class)
    rets = md.returns
    base = run_backtest(rets, strat, name="base")

    rng = np.random.default_rng(0)
    for t in [pd.Timestamp("1990-06-29"), pd.Timestamp("1995-12-29"), pd.Timestamp("1998-08-31")]:
        t = rets.index[rets.index.get_indexer([t], method="nearest")[0]]
        fake = rets.copy()
        after = fake.index > t
        noise = rng.normal(0, 0.3, size=fake.loc[after].shape)
        fake.loc[after] = np.where(fake.loc[after].notna(), noise, np.nan)
        alt = run_backtest(fake, strat, name="alt")

        w_base = base.weights.loc[:t]
        w_alt = alt.weights.loc[:t]
        pd.testing.assert_frame_equal(w_base, w_alt, check_exact=True)

        # Month t+1 return uses w_t and r_{t+1} only (here r_{t+1} is noise).
        t1 = rets.index[rets.index.get_loc(t) + 1]
        expected = float((w_alt.loc[t] * fake.loc[t1].fillna(0.0)).sum())
        assert alt.returns.loc[t1] == pytest.approx(expected, abs=1e-15)


def test_engine_hands_strategy_only_past_data(market):
    """The engine must call the strategy once per signal month, each time
    with a history that ends exactly at that month."""
    cfg, md = market
    rec = RecordingStrategy(CTAStrategy(cfg, "inverse_vol"))
    res = run_backtest(md.returns, rec, name="rec")
    dates = md.returns.index
    assert rec.seen == list(dates[:-1])
    # Held weights in month t+1 are exactly the weights decided at t.
    for t, t1 in zip(res.weights.index[:-1], res.weights.index[1:]):
        np.testing.assert_array_equal(res.held_weights.loc[t1].values, res.weights.loc[t].values)


def test_shock_in_next_month_is_not_anticipated(market):
    """Plant a +50% return for one instrument in month t+1. If there were
    look-ahead, the strategy would be long that instrument at t. Instead
    the position at t must equal the position without the shock."""
    cfg, md = market
    strat = CTAStrategy(cfg, "inverse_vol")
    rets = md.returns
    t = rets.index[100]
    t1 = rets.index[101]
    inst = rets.loc[t1].dropna().index[0]
    shocked = rets.copy()
    shocked.loc[t1, inst] = 0.5
    a = run_backtest(rets, strat, name="a")
    b = run_backtest(shocked, strat, name="b")
    assert a.weights.loc[t, inst] == b.weights.loc[t, inst]
    # The shock does move the next month's weights (the signal sees it then).
    t2 = rets.index[102]
    assert not np.isclose(a.weights.loc[t1, inst], b.weights.loc[t1, inst])
    # And the P&L difference in t+1 is exactly w_t * (0.5 - r_original).
    diff = b.returns.loc[t1] - a.returns.loc[t1]
    assert diff == pytest.approx(a.weights.loc[t, inst] * (0.5 - rets.loc[t1, inst]))
    assert t2 > t1


def test_ema_weights():
    w = ema_weights(12, 12)
    assert w.sum() == pytest.approx(1.0)
    assert np.all(np.diff(w) > 0)  # newest observation weighs most
    alpha = 2 / 13
    assert w[-2] / w[-1] == pytest.approx(1 - alpha)


def test_ema_volatility_matches_formula():
    idx = pd.date_range("2000-01-31", periods=12, freq="ME")
    x = pd.DataFrame({"A": np.linspace(-0.05, 0.06, 12)}, index=idx)
    w = ema_weights(12, 12)
    expected = np.sqrt((w * x["A"].values ** 2).sum() * 12)
    assert ema_volatility(x, 12, 12)["A"] == pytest.approx(expected)
    # A missing month drops out and the remaining weights are renormalised.
    x.iloc[3, 0] = np.nan
    m = ~np.isnan(x["A"].values)
    wm = w[m] / w[m].sum()
    expected = np.sqrt((wm * x["A"].values[m] ** 2).sum() * 12)
    assert ema_volatility(x, 12, 12)["A"] == pytest.approx(expected)


def test_erc_equalises_risk():
    rng = np.random.default_rng(1)
    idx = pd.date_range("2000-01-31", periods=36, freq="ME")
    x = pd.DataFrame(rng.normal(0, 1, (36, 6)) * [0.01, 0.02, 0.05, 0.03, 0.08, 0.04], index=idx)
    cov = ema_covariance(x, 36, 12, shrinkage=0.3).values
    w = erc_weights(cov)
    rc = risk_contributions(w, cov)
    np.testing.assert_allclose(rc, np.full(6, 1 / 6), atol=1e-6)
    assert w.sum() == pytest.approx(1.0)


def test_gap_fill_only_touches_blank_cells():
    from cta_backtest.data import fill_gaps_from_daily, load_returns
    raw = load_returns(os.path.join(ROOT, "data/MonthlyReturns_original.csv"))
    filled, log = fill_gaps_from_daily(raw, os.path.join(ROOT, "data/FuturesUnderlyingData.zip"))
    # The shipped MonthlyReturns.csv is exactly the original plus these fills.
    shipped = load_returns(os.path.join(ROOT, "data/MonthlyReturns.csv"))
    pd.testing.assert_frame_equal(shipped, filled, check_exact=False, rtol=1e-12, atol=1e-15)
    both = raw.notna()
    # Existing panel values are never changed.
    pd.testing.assert_frame_equal(raw[both], filled[both])
    # Every fill sits in a cell that was blank, after the instrument's start.
    for _, row in log.iterrows():
        d = pd.Timestamp(row["date"])
        assert np.isnan(raw.loc[d, row["instrument"]])
        assert d > raw[row["instrument"]].first_valid_index()


def test_start_date_trims_sample_without_dropping_warmup(market):
    """With a start date, the first P&L month is the start month, weights are
    first decided the month before, and those weights equal the ones a run
    without a start date produces (warm-up history is still used)."""
    cfg, md = market
    strat = CTAStrategy(cfg, "inverse_vol")
    full = run_backtest(md.returns, strat, name="full")
    cut = run_backtest(md.returns, strat, name="cut", start_date="1993-01")
    assert cut.returns.index[0] == pd.Timestamp("1993-01-29")
    assert cut.weights.index[0] == pd.Timestamp("1992-12-31")
    pd.testing.assert_series_equal(cut.weights.iloc[0], full.weights.loc["1992-12-31"], check_names=False)
    pd.testing.assert_series_equal(cut.returns, full.returns.loc["1993-01":], check_names=False)


def test_active_attribution_adds_up(market):
    from cta_backtest.attribution import active_attribution
    cfg, md = market
    ew = run_backtest(md.returns, CTAStrategy(cfg, "equal_weight"), name="ew")
    rp = run_backtest(md.returns, CTAStrategy(cfg, "inverse_vol"), name="rp")
    t = active_attribution(rp, ew, md.asset_class)
    total = t.loc["TOTAL"]
    assert total["difference"] == pytest.approx((rp.returns.mean() - ew.returns.mean()) * 12)
    assert total["leverage_effect"] + total["mix_effect"] + total["selection_effect"] == pytest.approx(total["difference"])
