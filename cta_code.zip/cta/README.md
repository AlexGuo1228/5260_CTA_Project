# Cross-asset CTA backtest

Monthly time-series momentum across FX, equity index, commodity and bond futures.
Baseline: equal weight. Test portfolio: risk parity on 12-month EMA volatility.

## Layout
- `cta_backtest/config.py`   all parameters (`BacktestConfig`)
- `cta_backtest/data.py`     load and clean the return panel and asset map
- `cta_backtest/signals.py`  12-month TSMOM sign
- `cta_backtest/risk.py`     EMA volatility / covariance on trailing windows
- `cta_backtest/weights.py`  eligibility, equal weight, inverse vol, ERC, class risk parity, vol target
- `cta_backtest/engine.py`   backtest loop with the one-month lag built in
- `cta_backtest/metrics.py`  return, vol, Sharpe, drawdown, turnover, asset-class breakdown
- `cta_backtest/attribution.py` long/short, instrument, yearly, active (leverage/mix/selection), factor regression
- `run_backtest.py`          runs every portfolio and writes `output/`
- `report_analysis.py`       data checks, rebuilt monthly series, static benchmark, correlations and alpha -> `output/report/`
- `tests/test_lookahead.py`  proofs that weights at t use data through t only

## Sample
Main sample is 1995-01 to 2014-12 (`start_date`); earlier history is used only as signal warm-up.
`data/MonthlyReturns.csv` has 32 holiday gaps filled from the daily zip (`data/filled_gaps.csv`);
the untouched upload is `data/MonthlyReturns_original.csv`.

## Run
    pip install -r requirements.txt
    python run_backtest.py
    python report_analysis.py
    python -m pytest -q

## No look-ahead, by construction
At each month-end t the engine passes the strategy `returns.iloc[:i+1]`, a copy that
ends at t. Weights are stored under t and multiplied only with the return row of t+1.
The tests scramble every return after t and assert the weights up to t are bit-for-bit
unchanged; a deliberately leaked version of the engine fails them.
