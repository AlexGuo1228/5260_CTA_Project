"""Data-quality and benchmark analysis behind the CTA report.

Steps:
  1. Outlier checks on the monthly panel and on the daily futures data.
  2. Re-create the monthly return series from daily closes and reconcile it
     with the uploaded panel.
  3. Baseline strategy (equal-weight 12-month TSMOM) and the risk parity
     version, from the same engine used by run_backtest.py.
  4. Static long-only benchmark built from the same universe, correlations
     and alpha regressions.

Usage:
    python report_analysis.py        # writes output/report/
"""
from __future__ import annotations

import io
import os
import zipfile
from dataclasses import replace

import numpy as np
import pandas as pd

from cta_backtest import BacktestConfig, CTAStrategy, load_market_data, metrics, run_backtest
from cta_backtest.attribution import factor_series
from cta_backtest.data import load_returns
from cta_backtest.weights import eligible_mask

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output", "report")


# ---------------------------------------------------------------------------
# 1. Outlier checks
# ---------------------------------------------------------------------------

def monthly_outliers(rets: pd.DataFrame, window: int = 36, z: float = 5.0,
                     abs_cut: float = 0.30) -> pd.DataFrame:
    """Flag monthly returns that are extreme relative to the instrument's own
    trailing volatility (past `window` months, excluding the month itself),
    or larger than `abs_cut` in absolute value."""
    trailing_vol = rets.rolling(window, min_periods=12).std().shift(1)
    zscore = rets / trailing_vol
    flag = (zscore.abs() > z) | (rets.abs() > abs_cut)
    rows = []
    for d, c in zip(*np.where(flag.values)):
        date, inst = rets.index[d], rets.columns[c]
        rows.append({"date": date.date(), "instrument": inst, "return": rets.iat[d, c],
                     "trailing_vol": trailing_vol.iat[d, c], "z": zscore.iat[d, c]})
    return pd.DataFrame(rows).sort_values("z", key=lambda s: -s.abs())


def daily_checks(zip_path: str) -> pd.DataFrame:
    """Per instrument: price sanity checks on the daily file."""
    rows = []
    with zipfile.ZipFile(zip_path) as zf:
        for fn in sorted(zf.namelist()):
            d = pd.read_csv(io.BytesIO(zf.read(fn)), index_col=0, parse_dates=True)
            inst = fn[:-4]
            close = d["Close"]
            r = close.pct_change(fill_method=None)
            vol = r.rolling(60, min_periods=20).std().shift(1)
            jumps = (r.abs() / vol) > 10
            same = close.diff().eq(0)
            # Longest run of identical consecutive closes (stale prices).
            run = same.groupby((~same).cumsum()).cumsum().max()
            rows.append({
                "instrument": inst,
                "first": d.index.min().date(),
                "last": d.index.max().date(),
                "days": len(d),
                "min_close": close.min(),
                "non_positive_close": int((close <= 0).sum()),
                "high_below_low": int((d["High"] < d["Low"]).sum()),
                "close_outside_range": int(((close > d["High"] + 1e-9) | (close < d["Low"] - 1e-9)).sum()),
                "missing_close": int(close.isna().sum()),
                "duplicate_dates": int(d.index.duplicated().sum()),
                "jumps_gt_10sd": int(jumps.sum()),
                "max_abs_daily_ret": r.abs().max(),
                "longest_stale_run": int(run) if pd.notna(run) else 0,
            })
    return pd.DataFrame(rows).set_index("instrument")


def daily_explains_monthly(zip_path: str, outliers: pd.DataFrame) -> pd.DataFrame:
    """For each flagged month, check that the daily path reproduces the move
    and report the largest single-day move inside that month."""
    out = []
    with zipfile.ZipFile(zip_path) as zf:
        names = set(zf.namelist())
        for _, row in outliers.iterrows():
            fn = f"{row['instrument']}.csv"
            if fn not in names:
                continue
            d = pd.read_csv(io.BytesIO(zf.read(fn)), index_col=0, parse_dates=True)["Close"]
            m = pd.Period(row["date"], "M")
            prev_close = d[d.index.to_period("M") < m]
            inside = d[d.index.to_period("M") == m]
            if prev_close.empty or inside.empty:
                continue
            path = pd.concat([prev_close.iloc[-1:], inside])
            daily = path.pct_change().dropna()
            out.append({**row.to_dict(),
                        "daily_rebuilt_return": inside.iloc[-1] / prev_close.iloc[-1] - 1,
                        "trading_days": len(inside),
                        "largest_day": daily.abs().max(),
                        "largest_day_date": daily.abs().idxmax().date(),
                        "share_from_largest_day": daily.abs().max() / abs(row["return"])})
    return pd.DataFrame(out)


# ---------------------------------------------------------------------------
# 2. Re-create monthly returns from daily closes
# ---------------------------------------------------------------------------

def rebuild_monthly(zip_path: str) -> pd.DataFrame:
    """Monthly simple returns from the last daily close of each calendar
    month, for every instrument in the zip."""
    series = {}
    with zipfile.ZipFile(zip_path) as zf:
        for fn in zf.namelist():
            close = pd.read_csv(io.BytesIO(zf.read(fn)), index_col=0, parse_dates=True)["Close"].dropna()
            series[fn[:-4]] = close.groupby(close.index.to_period("M")).last().pct_change(fill_method=None)
    return pd.DataFrame(series).sort_index()


def reconcile(panel: pd.DataFrame, rebuilt: pd.DataFrame) -> pd.DataFrame:
    """Cell-by-cell comparison of the uploaded panel with the rebuilt series."""
    p = panel.copy()
    p.index = p.index.to_period("M")
    rows = []
    for c in p.columns:
        if c not in rebuilt.columns:
            rows.append({"instrument": c, "status": "no daily file"})
            continue
        a = p[c]
        b = rebuilt[c].reindex(a.index)
        both = a.notna() & b.notna()
        fv = a.first_valid_index()
        after = a.index > fv if fv is not None else np.zeros(len(a), bool)
        rows.append({
            "instrument": c,
            "status": "ok",
            "cells_compared": int(both.sum()),
            "max_abs_diff": float((a[both] - b[both]).abs().max()) if both.any() else np.nan,
            "panel_blank_daily_has": int((a.isna() & b.notna() & after).sum()),
            "panel_has_daily_blank": int((a.notna() & b.isna()).sum()),
        })
    return pd.DataFrame(rows).set_index("instrument")


# ---------------------------------------------------------------------------
# 3-4. Strategies, static benchmark, correlations, alpha
# ---------------------------------------------------------------------------

class StaticLongOnly:
    """Static benchmark: equal weight, long only, across the instruments the
    CTA could trade that month (same eligibility rules, no trend signal).
    Gross exposure is 1, so this is a passive diversified futures basket."""

    def __init__(self, cfg: BacktestConfig):
        self.cfg = cfg

    def compute_weights(self, history: pd.DataFrame) -> pd.Series:
        lookback = max(self.cfg.momentum_lookback, self.cfg.vol_window)
        elig = eligible_mask(history, lookback, self.cfg.min_obs)
        w = pd.Series(0.0, index=history.columns)
        n = int(elig.sum())
        if n >= self.cfg.min_assets:
            w[elig] = 1.0 / n
        return w


def regress(y: pd.Series, x: pd.Series) -> dict:
    """Single-factor OLS y = a + b x + e with annualised alpha."""
    df = pd.concat([y.rename("y"), x.rename("x")], axis=1).dropna()
    X = np.column_stack([np.ones(len(df)), df["x"].to_numpy()])
    beta, *_ = np.linalg.lstsq(X, df["y"].to_numpy(), rcond=None)
    resid = df["y"].to_numpy() - X @ beta
    s2 = resid @ resid / (len(df) - 2)
    se = np.sqrt(np.diag(s2 * np.linalg.inv(X.T @ X)))
    return {"alpha_ann": beta[0] * 12, "alpha_t": beta[0] / se[0], "beta": beta[1],
            "beta_t": beta[1] / se[1], "r2": 1 - resid @ resid / ((df["y"] - df["y"].mean()) ** 2).sum(),
            "info_ratio": beta[0] * 12 / (resid.std(ddof=2) * np.sqrt(12)), "months": len(df)}


def main():
    os.chdir(HERE)
    os.makedirs(OUT, exist_ok=True)
    cfg = BacktestConfig()
    md = load_market_data(cfg)

    # 1. Outliers
    original = load_returns("data/MonthlyReturns_original.csv")
    out_m = monthly_outliers(original)
    out_m.to_csv(os.path.join(OUT, "monthly_outliers.csv"), index=False)
    explained = daily_explains_monthly(cfg.daily_zip_path, out_m)
    explained.to_csv(os.path.join(OUT, "monthly_outliers_vs_daily.csv"), index=False)
    dchk = daily_checks(cfg.daily_zip_path)
    dchk.to_csv(os.path.join(OUT, "daily_checks.csv"))

    # 2. Rebuild and reconcile
    rebuilt = rebuild_monthly(cfg.daily_zip_path)
    rebuilt.to_csv(os.path.join(OUT, "monthly_rebuilt_from_daily.csv"))
    rec = reconcile(original, rebuilt)
    rec.to_csv(os.path.join(OUT, "reconciliation.csv"))
    # Mini contracts that only exist in the zip vs their full-size twin.
    twins = {"ES": "SP", "SC": "SP", "EN": "ND", "ER": "RL"}
    p = original.copy()
    p.index = p.index.to_period("M")
    twin_rows = []
    for mini, full in twins.items():
        both = pd.concat([rebuilt[mini], p[full]], axis=1).dropna()
        twin_rows.append({"mini": mini, "full": full, "months": len(both),
                          "corr": both.corr().iloc[0, 1],
                          "mean_abs_diff": (both.iloc[:, 0] - both.iloc[:, 1]).abs().mean()})
    pd.DataFrame(twin_rows).to_csv(os.path.join(OUT, "mini_vs_full.csv"), index=False)

    # 3. Strategies on the main sample
    def run(strat, name):
        return run_backtest(md.returns, strat, name=name, start_date=cfg.start_date, end_date=cfg.end_date)

    vt = replace(cfg, vol_target=0.10)
    res = {
        "baseline_ew": run(CTAStrategy(cfg, "equal_weight"), "baseline_ew"),
        "baseline_ew_vt10": run(CTAStrategy(vt, "equal_weight"), "baseline_ew_vt10"),
        "risk_parity_vt10": run(CTAStrategy(vt, "inverse_vol"), "risk_parity_vt10"),
        "static_ew_long": run(StaticLongOnly(cfg), "static_ew_long"),
    }
    metrics.compare(res.values()).to_csv(os.path.join(OUT, "strategy_vs_static_summary.csv"))

    # 4. Correlations and alpha
    fac = factor_series(md.returns, md.asset_class).loc[res["static_ew_long"].returns.index]
    panel = pd.DataFrame({k: r.returns for k, r in res.items()})
    panel = pd.concat([panel, fac.add_prefix("passive_")], axis=1)
    panel.corr().to_csv(os.path.join(OUT, "correlation_matrix.csv"))

    static = res["static_ew_long"].returns
    worst = static <= static.quantile(0.2)
    cond = pd.DataFrame({
        "corr_all": panel.corrwith(static),
        "corr_static_down_months": panel[worst].corrwith(static[worst]),
        "corr_static_up_months": panel[~worst].corrwith(static[~worst]),
        "avg_ret_static_worst20pct": panel[worst].mean(),
    })
    cond.to_csv(os.path.join(OUT, "correlation_conditional.csv"))

    roll = pd.DataFrame({k: panel[k].rolling(36).corr(static)
                         for k in ("baseline_ew_vt10", "risk_parity_vt10")})
    roll.to_csv(os.path.join(OUT, "rolling_36m_corr_vs_static.csv"))

    alpha = pd.DataFrame({k: regress(res[k].returns, static)
                          for k in ("baseline_ew", "baseline_ew_vt10", "risk_parity_vt10")}).T
    alpha.to_csv(os.path.join(OUT, "alpha_vs_static.csv"))

    # Cumulative alpha: strategy minus beta * static, compounded.
    cum = {}
    for k in ("baseline_ew_vt10", "risk_parity_vt10"):
        b = alpha.loc[k, "beta"]
        cum[k] = (1 + (res[k].returns - b * static)).cumprod()
    cum["static_ew_long"] = (1 + static).cumprod()
    pd.DataFrame(cum).to_csv(os.path.join(OUT, "cumulative_alpha.csv"))

    print(metrics.compare(res.values()).loc[["ann_return", "ann_vol", "sharpe", "max_drawdown"]])
    print(alpha)


if __name__ == "__main__":
    main()
