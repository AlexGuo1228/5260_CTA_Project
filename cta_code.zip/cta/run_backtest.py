"""Run the CTA backtest: equal-weight baseline vs risk parity.

Usage:
    python run_backtest.py            # writes tables and charts to output/

All runs share the same universe, signal, eligibility rules and sample, so
differences come only from the weighting scheme (and, for the *_vt10 runs,
from the 10% ex-ante volatility target).
"""
from __future__ import annotations

import json
import os
from dataclasses import replace

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

from cta_backtest import BacktestConfig, CTAStrategy, coverage_table, load_market_data, metrics, run_backtest  # noqa: E402
from cta_backtest import attribution  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output")

# Chart colours (validated categorical slots, light mode).
COLORS = {
    "equal_weight": "#eb6834",
    "risk_parity": "#2a78d6",
    "erc": "#1baf7a",
    "class_risk_parity": "#4a3aa7",
}
INK, MUTED, GRID = "#0b0b0b", "#52514e", "#e6e5e0"

SUBPERIODS = {
    "1995-1999": ("1995", "1999"),
    "2000-2007": ("2000", "2007"),
    "2008": ("2008", "2008"),
    "2009-2014": ("2009", "2014"),
}


def make_runs(cfg: BacktestConfig, md):
    """(label, weighting, config) for every run."""
    vt = replace(cfg, vol_target=0.10)
    return [
        ("equal_weight", "equal_weight", cfg),
        ("risk_parity", "inverse_vol", cfg),
        ("erc", "erc", cfg),
        ("class_risk_parity", "class_risk_parity", cfg),
        ("equal_weight_vt10", "equal_weight", vt),
        ("risk_parity_vt10", "inverse_vol", vt),
        ("risk_parity_vt10_floor2", "inverse_vol", replace(vt, vol_floor=0.02)),
    ]


def style(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(MUTED)
    ax.tick_params(colors=MUTED, labelsize=9)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def plot_lines(series: dict, title: str, ylabel: str, path: str, log: bool = False, pct: bool = False):
    fig, ax = plt.subplots(figsize=(10, 4.8), dpi=130)
    for label, s in series.items():
        key = label.replace("_vt10", "").replace("_floor2", "")
        ax.plot(s.index, s.values, color=COLORS.get(key, MUTED), linewidth=1.6, label=label)
        ax.annotate(label, (s.index[-1], s.values[-1]), xytext=(4, 0), textcoords="offset points",
                    fontsize=8, color=INK, va="center")
    if log:
        ax.set_yscale("log")
    if pct:
        ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.set_title(title, loc="left", fontsize=12, color=INK)
    ax.set_ylabel(ylabel, color=MUTED, fontsize=9)
    ax.legend(frameon=False, fontsize=9, loc="upper left")
    style(ax)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_class_weights(res, asset_class, path):
    cls = asset_class.reindex(res.held_weights.columns)
    g = res.held_weights.abs().T.groupby(cls).sum().T
    g = g.div(g.sum(axis=1), axis=0).resample("YE").mean()
    order = ["COMM", "EQ", "FI", "FX"]
    cols = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
    fig, ax = plt.subplots(figsize=(10, 4.2), dpi=130)
    ax.stackplot(g.index, [g[c] for c in order], labels=order, colors=cols, edgecolor="white", linewidth=0.6)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.set_ylim(0, 1)
    ax.set_title(f"Share of gross exposure by asset class: {res.name}", loc="left", fontsize=12, color=INK)
    ax.legend(frameon=False, fontsize=9, ncol=4, loc="upper left", bbox_to_anchor=(0, -0.08))
    style(ax)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def write_attribution(results, md):
    """Attribution tables for the main pair under the 10% vol target, which
    compares the two weighting schemes at the same risk level."""
    adir = os.path.join(OUT, "attribution")
    os.makedirs(adir, exist_ok=True)
    pairs = [("equal_weight_vt10", "risk_parity_vt10"), ("equal_weight", "risk_parity")]
    for k in ("equal_weight_vt10", "risk_parity_vt10"):
        r = results[k]
        attribution.by_long_short(r, md.asset_class).to_csv(os.path.join(adir, f"long_short_{k}.csv"))
        attribution.by_instrument(r, md.asset_class, md.names).to_csv(os.path.join(adir, f"instrument_{k}.csv"))
        attribution.by_year_and_class(r, md.asset_class).to_csv(os.path.join(adir, f"yearly_class_{k}.csv"))
    for bench, port in pairs:
        attribution.active_attribution(results[port], results[bench], md.asset_class).to_csv(
            os.path.join(adir, f"active_{port}_vs_{bench}.csv"))

    factors = attribution.factor_series(md.returns, md.asset_class)
    reg = pd.DataFrame({k: attribution.factor_regression(r.returns, factors) for k, r in results.items()})
    reg.to_csv(os.path.join(adir, "factor_regression.csv"))
    cond = pd.DataFrame({k: attribution.conditional_on_equity(r.returns, factors["EQUITY"])
                         for k, r in results.items()})
    cond.to_csv(os.path.join(adir, "equity_conditional.csv"))


def main():
    os.chdir(HERE)
    os.makedirs(OUT, exist_ok=True)
    cfg = BacktestConfig()
    md = load_market_data(cfg)
    coverage_table(md).to_csv(os.path.join(OUT, "universe_coverage.csv"))

    def run(label, weighting, c):
        strat = CTAStrategy(c, weighting, asset_class=md.asset_class)
        return run_backtest(md.returns, strat, name=label, cost_bps=c.cost_bps,
                            start_date=c.start_date, end_date=c.end_date)

    results = {label: run(label, w, c) for label, w, c in make_runs(cfg, md)}

    # Robustness: the same main runs over the full history (no start date).
    full_cfg = replace(cfg, start_date=None)
    full = {label: run(label, w, c) for label, w, c in make_runs(full_cfg, md)
            if label in ("equal_weight", "risk_parity", "equal_weight_vt10", "risk_parity_vt10")}
    metrics.compare(full.values()).to_csv(os.path.join(OUT, "summary_full_sample.csv"))

    # Every run must cover the same months, otherwise comparisons are unfair.
    idx = {tuple(r.returns.index) for r in results.values()}
    assert len(idx) == 1, "Runs cover different samples"

    summary = metrics.compare(results.values())
    summary.to_csv(os.path.join(OUT, "summary.csv"))

    cls_tables = []
    for label, r in results.items():
        t = metrics.by_asset_class(r, md.asset_class)
        t.insert(0, "portfolio", label)
        cls_tables.append(t.reset_index())
    pd.concat(cls_tables).to_csv(os.path.join(OUT, "by_asset_class.csv"), index=False)

    sub = []
    for label, r in results.items():
        t = metrics.subperiod_stats(r, SUBPERIODS)
        t.insert(0, "portfolio", label)
        sub.append(t.rename_axis("period").reset_index())
    pd.concat(sub).to_csv(os.path.join(OUT, "subperiods.csv"), index=False)

    write_attribution(results, md)

    pd.DataFrame({k: r.returns for k, r in results.items()}).to_csv(os.path.join(OUT, "monthly_returns.csv"))
    pd.DataFrame({k: r.turnover for k, r in results.items()}).to_csv(os.path.join(OUT, "turnover.csv"))
    for k in ("equal_weight", "risk_parity"):
        results[k].weights.to_csv(os.path.join(OUT, f"weights_{k}.csv"))

    main_pair = ["equal_weight", "risk_parity"]
    vt_pair = ["equal_weight_vt10", "risk_parity_vt10"]
    plot_lines({k: metrics.nav(results[k].returns) for k in main_pair},
               "Cumulative NAV, gross exposure = 1", "NAV (log)", os.path.join(OUT, "nav_gross1.png"), log=True)
    plot_lines({k: metrics.nav(results[k].returns) for k in vt_pair},
               "Cumulative NAV, 10% ex-ante vol target", "NAV (log)", os.path.join(OUT, "nav_vt10.png"), log=True)
    plot_lines({k: metrics.drawdown(results[k].returns) for k in vt_pair},
               "Drawdown, 10% ex-ante vol target", "Drawdown", os.path.join(OUT, "drawdown_vt10.png"), pct=True)
    plot_lines({k: results[k].returns.rolling(36).std() * 12 ** 0.5 for k in vt_pair},
               "Rolling 36-month realised vol, 10% target", "Annualised vol", os.path.join(OUT, "rolling_vol_vt10.png"), pct=True)
    plot_lines({k: results[k].turnover.iloc[1:].rolling(12).sum() for k in main_pair},
               "Rolling 12-month turnover (sum |dw|), gross exposure = 1", "Turnover x gross",
               os.path.join(OUT, "turnover.png"))
    for k in main_pair:
        plot_class_weights(results[k], md.asset_class, os.path.join(OUT, f"class_exposure_{k}.png"))

    with open(os.path.join(OUT, "config.json"), "w") as f:
        json.dump(cfg.to_dict(), f, indent=2)

    pd.set_option("display.width", 200)
    pd.set_option("display.float_format", lambda x: f"{x:,.4f}")
    print(summary)


if __name__ == "__main__":
    main()
